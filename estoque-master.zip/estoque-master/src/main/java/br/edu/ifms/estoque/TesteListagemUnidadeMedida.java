
package br.edu.ifms.estoque;

import br.edu.ifms.estoque.view.TelaListagemUnidadeMedida;
import javax.swing.JFrame;

public class TesteListagemUnidadeMedida {

    public static void main(String[] args) {
        TelaListagemUnidadeMedida tela = new TelaListagemUnidadeMedida();
        tela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        tela.pack();
        tela.setLocationRelativeTo(null);
        tela.setVisible(true);
    }
}
