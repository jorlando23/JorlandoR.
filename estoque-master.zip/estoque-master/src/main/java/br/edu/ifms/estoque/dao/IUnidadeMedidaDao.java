
package br.edu.ifms.estoque.dao;

import br.edu.ifms.estoque.model.UnidadeMedida;
import java.util.List;

public interface IUnidadeMedidaDao extends IDao {

    public UnidadeMedida buscarPorId(Long id);

    public List buscarPorNome(String nome);
}
