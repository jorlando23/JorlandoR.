
package br.edu.ifms.estoque.dao;

import br.edu.ifms.estoque.model.Marca;
import java.util.List;

public interface IMarcaDao extends IDao {

    public Marca buscarPorId(Long id);

    public List buscarPorNome(String nome);
}
