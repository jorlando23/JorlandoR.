/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifms.estoque.view;

import javax.swing.JFrame;

/**
 *
 * @author santos
 */
public class DisplayQueryTest {
    public static void main(String[] args) {
        DisplayQueryResults tela = new DisplayQueryResults();
        tela.setSize(500, 250);
        tela.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        tela.setVisible(true);
    }
}
