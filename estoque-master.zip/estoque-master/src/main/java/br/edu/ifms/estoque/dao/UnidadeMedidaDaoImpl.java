
package br.edu.ifms.estoque.dao;

import br.edu.ifms.estoque.database.Conexao;
import br.edu.ifms.estoque.model.UnidadeMedida;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class UnidadeMedidaDaoImpl implements IUnidadeMedidaDao {

    private static final String UNIDADE_MEDIDA_SQL = "SELECT id, nome, fracionado "
                    + "  FROM unidade_medida ";

    private Conexao conexao;
    private Connection conn;

    public UnidadeMedidaDaoImpl(Conexao conexao) {
        this.conexao = conexao;
        this.conn = conexao.getConn();
    }

    @Override
    public UnidadeMedida buscarPorId(Long id) {
        ResultSet rs = null;
        UnidadeMedida UnidadeMedida = null;
        try {
            PreparedStatement stmt = conn.prepareStatement(UNIDADE_MEDIDA_SQL
                    + " WHERE id = ? ");
            stmt.setLong(1, id);
            rs = stmt.executeQuery();
            if (rs.next()) {
                UnidadeMedida = new UnidadeMedida();
                UnidadeMedida.setId(rs.getLong(1));
                UnidadeMedida.setNome(rs.getString(2));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return UnidadeMedida;
    }

    @Override
    public List buscarPorNome(String nome) {
        ResultSet rs = null;
        List<UnidadeMedida> resultList = null;
        try {
            PreparedStatement stmt = conn.prepareStatement(UNIDADE_MEDIDA_SQL
                    + " WHERE nome LIKE ? ");
            stmt.setString(1, nome);
            rs = stmt.executeQuery();
            resultList = new ArrayList();
            while (rs.next()) {
                UnidadeMedida UnidadeMedida = new UnidadeMedida();
                UnidadeMedida.setId(rs.getLong(1));
                UnidadeMedida.setNome(rs.getString(2));
                resultList.add(UnidadeMedida);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return resultList;
    }

    @Override
    public Object inserir(Object object) {
        UnidadeMedida UnidadeMedida = (UnidadeMedida) object;
        try {
            PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO unidade_medida (nome) VALUES (?)",
                    Statement.RETURN_GENERATED_KEYS
            );
            stmt.setString(1, UnidadeMedida.getNome());
            int affectedRows = stmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Creating unidadeMedida failed, no rows affected.");
            }
            
            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    UnidadeMedida.setId(generatedKeys.getLong(1));
                } else {
                    throw new SQLException("Creating unidadeMedida failed, no ID obtained.");
                }
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return UnidadeMedida;
    }

    @Override
    public Object alterar(Object object) {
        UnidadeMedida UnidadeMedida = (UnidadeMedida) object;
        try {
            PreparedStatement stmt = conn.prepareStatement(
                    " UPDATE unidade_medida SET nome = ? WHERE id = ? "
            );
            stmt.setString(1, UnidadeMedida.getNome());
            stmt.setLong(2, UnidadeMedida.getId());
            int affectedRows = stmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Updating unidadeMedida failed, no rows affected.");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return UnidadeMedida;
    }

    @Override
    public void excluir(Object object) {
        UnidadeMedida UnidadeMedida = (UnidadeMedida) object;
        try {
            PreparedStatement stmt = conn.prepareStatement(
                    " DELETE FROM unidade_medida WHERE id = ? "
            );
            stmt.setLong(1, UnidadeMedida.getId());
            int affectedRows = stmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Deleting unidadeMedida failed, no rows affected.");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public List listar() {
        ResultSet rs = null;
        List<UnidadeMedida> resultList = null;
        try {
            PreparedStatement stmt = conn.prepareStatement(UNIDADE_MEDIDA_SQL);
            rs = stmt.executeQuery();
            resultList = new ArrayList();
            while (rs.next()) {
                UnidadeMedida UnidadeMedida = new UnidadeMedida();
                UnidadeMedida.setId(rs.getLong(1));
                UnidadeMedida.setNome(rs.getString(2));
                resultList.add(UnidadeMedida);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                rs.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return resultList;
    }

}
